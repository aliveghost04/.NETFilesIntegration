﻿using EasyHttp.Http;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using UploadXMLFile.Libs;


namespace UploadXMLFile.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {   
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        public ActionResult Upload()
        {
            var fileUpload = Request.Files["FileUpload"];
            var http = new HttpClient();

            byte[] data = new byte[fileUpload.ContentLength];
            fileUpload.InputStream.Read(data, 0, (int) fileUpload.InputStream.Length);

            var client = new RestClient();
            client.BaseUrl = new Uri("http://localhost:49232");
            var request = new RestRequest();
            request.Resource = "XMLManager/PullXml";
            request.AddFile("FileUpload", data, fileUpload.FileName);
            request.AddHeader("Content-Type", "multipart/form-data");
            var result = client.Execute(request);
            /*
            
            // Generate post objects
            Dictionary<string, object> postParameters = new Dictionary<string, object>();
            postParameters.Add("FileUpload", new FormUpload.FileParameter(data, fileUpload.FileName, fileUpload.ContentType));

            // Create request and receive response
            string postURL = "http://localhost:49232/XMLManager/PullXml";
            string userAgent = "Someone";
            HttpWebResponse webResponse = FormUpload.MultipartFormDataPost(postURL, userAgent, postParameters);

            // Process response
            StreamReader responseReader = new StreamReader(webResponse.GetResponseStream());
            string fullResponse = responseReader.ReadToEnd();
            webResponse.Close();*/
            return View("Index");
        }
    }
}